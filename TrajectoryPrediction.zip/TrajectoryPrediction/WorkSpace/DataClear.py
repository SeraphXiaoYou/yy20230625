import pandas as pd
import os
import csv

file_dir = "D:\PycharmDoct\\ffafaa"  # file dir
all_csv_list = os.listdir(file_dir)  # get csv list
for single_csv in all_csv_list:
    with open(os.path.join(file_dir, single_csv), 'r') as f:
        df = pd.read_csv(os.path.join(file_dir, single_csv), header=None)
        df.drop(df.columns[[1,2,3,6,7,8,9,10,11,12,13]], axis=1, inplace=True)  # 删掉无意义的2,3,4,7,8,9,10,11,12,13,14列
        df.insert(0, 'TimeSeries', '')
        i=1
        reader = csv.reader(f)
        for row in reader:
            row[0]=i
            i=i+1
        df.to_csv(os.path.join(file_dir, single_csv), index=False,header=False)
print("处理成功")


with open(r'D:\PycharmDoct\ffafaa\00000059.txt', 'r') as f1:
    f2 = open("D:\PycharmDoct\\ffafaa\\59.txt", "w")
    lines = f1.readlines()  # 读取文本每一行
    #print(lines)
    for i in lines:  # readlines以列表输出文件内容
        i = i.replace(",", "\t")  # 改变元素，去掉逗号，和换行符\n,tab键则把逗号换成"\t",空格换成" "
        f2.write(i)
    print('处理成功')

