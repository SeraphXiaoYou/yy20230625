import folium
import pandas as pd
from folium.plugins import HeatMap

# limit = 900
# df = pd.read_csv('D:\PycharmDoct\dbscan\\all.csv',usecols=[0,1],header=0,names=['lat_Amap', 'lng_Amap'])
# data = df.iloc[0:limit, :]
# san_map = folium.Map(location=[35.695794, 139.746188], zoom_start=12,attr='default')
# # Convert data format
# heatdata = data[['lat_Amap', 'lng_Amap']].values.tolist()
# # add incidents to map
# HeatMap(heatdata).add_to(san_map)
# san_map.save('relitu.html')

import folium
from folium.plugins import HeatMap


location_book = pd.read_csv('D:\PycharmDoct\dbscan\\all.csv',usecols=[0,1],header=0,names=['lat_Amap', 'lng_Amap'])
lng = location_book['lng_Amap'].values.tolist()
lat = location_book['lat_Amap'].values.tolist()
for i in range(0, len(lng)):
    print(lng[i])

data = []
for i in range(0, len(lng)):
    temp = []
    temp.append(lat[i])
    temp.append(lng[i])
    temp.append(0.1)
    data.append(temp)
mp = folium.Map(location=[35.695794, 139.746188], zoom_start=12)
HeatMap(data[0:400]).add_to(mp)
mp.save('Heatmap.html')