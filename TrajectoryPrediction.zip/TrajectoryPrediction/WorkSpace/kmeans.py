
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# ------ 1.1.导入数据 ------
df = pd.read_csv('E:/pyDoct/China_cities.csv')
print(df.shape)    # 输出数据维度
print(df.head())  # 展示前5行数据

# ------ 2.1.提取经纬度数据 ------

x = df.drop('省级行政区', axis=1)
x = x.drop("城市", axis=1)
x_np = np.array(x)        # 将x转化为numpy数组


# ------ 3.1.构造K-Means聚类器 ------
n_clusters = 7                  # 类簇的数量
estimator = KMeans(n_clusters)  # 构建聚类器

# ------ 3.2.训练K-Means聚类器 ------
estimator.fit(x)

markers = ['*', 'v', '+', '^', 's', 'x', 'o']      # 标记样式列表
colors = ['r', 'g', 'm', 'c', 'y', 'b', 'orange']  # 标记颜色列表
labels = estimator.labels_      # 获取聚类标签

plt.figure(figsize=(9, 6))
plt.title("Major Cities in China", fontsize=25)
plt.xlabel('East Longitude', fontsize=18)
plt.ylabel('North Latitude', fontsize=18)

for i in range(n_clusters):
    members = labels == i      # members是一个布尔型数组
    plt.scatter(
        x_np[members, 1],      # 城市经度数组
        x_np[members, 0],      # 城市纬度数组
        marker = markers[i],   # 标记样式
        c = colors[i]          # 标记颜色
    )   # 绘制散点图

plt.grid()
plt.show()