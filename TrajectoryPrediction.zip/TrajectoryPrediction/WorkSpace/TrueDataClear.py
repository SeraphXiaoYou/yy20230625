import pandas as pd
import os
import csv

file_dir = "D:\\PycharmDoct\\shenzhen"  # file dir       真正的将原始数据剔除为无重复的干净数据
all_csv_list = os.listdir(file_dir)  # get csv list
for single_csv in all_csv_list:
    with open(os.path.join(file_dir, single_csv), 'r',encoding='UTF-8') as f:
        TripPurpose = []  # 存放经度大小
        drop_list = []  # 存放待删除的行
        reader = csv.reader(f)
        for row in reader:
            TripPurpose.append(row[1])
        for i in range(0, len(TripPurpose) - 1):
            if (TripPurpose[i] == TripPurpose[i + 1]):
                drop_list.append(i)
        for j in TripPurpose:
            print(j)
        for k in drop_list:
            print(k)
        df = pd.read_csv(os.path.join(file_dir, single_csv), header=None)
        df.drop(drop_list, inplace=True)  # 重复经度，只留最后一个
        #df.drop(df.columns[[8, 12]], axis=1, inplace=True)  # 删掉无意义的第9和第13列
        df.to_csv(os.path.join(file_dir, single_csv), index=False,header=False)
print("处理成功")


