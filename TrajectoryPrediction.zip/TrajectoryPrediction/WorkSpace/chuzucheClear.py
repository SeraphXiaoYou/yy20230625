import pandas as pd
import os
import csv

file_dir = "D:\\PycharmDoct\\hhhh"  # file dir       真正的将原始数据剔除为无重复的干净数据
all_csv_list = os.listdir(file_dir)  # get csv list
for single_csv in all_csv_list:
    with open(os.path.join(file_dir, single_csv), 'r') as f:
        df = pd.read_csv(os.path.join(file_dir, single_csv))
        df4 = df.drop(labels=[1201,1048576])  # 等价于df.drop(labels=[0,1])
        df.to_csv(os.path.join(file_dir, single_csv), index=False)
print("处理成功")


